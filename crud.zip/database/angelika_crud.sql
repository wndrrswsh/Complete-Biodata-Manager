-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Mar 02, 2026 at 04:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `angelika_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `educational_background`
--

CREATE TABLE `educational_background` (
  `education_id` int(255) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `level` varchar(255) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year_passing` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `educational_background`
--

INSERT INTO `educational_background` (`education_id`, `personal_id`, `level`, `school_name`, `course`, `year_passing`) VALUES
(12, 18, 'Highschool', 'pangetka', 'BSIT', '2025'),
(13, 19, 'Elementary', 'tangina may nangyayari na', 'BSIT', '2003'),
(14, 21, 'Elementary', 'NEUST', 'BSIT', '2025');

-- --------------------------------------------------------

--
-- Table structure for table `employment_history`
--

CREATE TABLE `employment_history` (
  `employment_id` int(11) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employment_history`
--

INSERT INTO `employment_history` (`employment_id`, `personal_id`, `company_name`, `position`, `start_date`, `end_date`) VALUES
(4, 19, 'Company1', 'poooo', '1111-11-11', '1111-11-11'),
(5, 19, 'Company1', 'Position1', '1111-11-11', '1111-11-11'),
(6, 20, 'Company ABC', 'Driver', '2001-12-11', '2003-11-11'),
(7, 20, 'Company ABC', 'Driver', '2001-12-11', '2003-11-11'),
(8, 21, 'Company111', 'Position1', '1998-11-11', '2001-11-11'),
(9, 21, 'Company111', 'Position1', '1998-11-11', '2001-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `id`
--

CREATE TABLE `id` (
  `id` int(255) NOT NULL,
  `First_name` varchar(255) NOT NULL,
  `Middle_name` varchar(255) NOT NULL,
  `Last_name` varchar(255) NOT NULL,
  `Suffix` varchar(255) NOT NULL,
  `Languages` varchar(255) NOT NULL,
  `Email_address` varchar(255) NOT NULL,
  `Hobbies` varchar(255) NOT NULL,
  `Mobile_number` varchar(255) NOT NULL,
  `Religion` varchar(255) NOT NULL,
  `Province` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `Barangay` varchar(255) NOT NULL,
  `Street` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Marital_status` varchar(255) NOT NULL,
  `DOB` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `id`
--

INSERT INTO `id` (`id`, `First_name`, `Middle_name`, `Last_name`, `Suffix`, `Languages`, `Email_address`, `Hobbies`, `Mobile_number`, `Religion`, `Province`, `City`, `Barangay`, `Street`, `Gender`, `Marital_status`, `DOB`) VALUES
(18, 'Angelika', 'Liwag', 'Solemam', 'None', 'English', 'angelikasoledad22@gmail.com', 'Singing', '639930257081', 'Catholic', 'Nueva Ecija', 'Jaen', 'Navao', 'San Josef (Nabao), Jaen, Nueva Ecija', 'Female', 'Single', '2003-12-12'),
(19, 'Grego', 'Liwag', 'Limaw', 'None', 'English', 'angelikasoledad22@gmail.com', 'Singing', '8387081', 'Catholic', 'Nueva Ecija', 'Jaen', 'Navao', 'Lopez Street', 'Female', 'Single', '2004-12-12'),
(20, 'Liam', 'Eduardo', 'Cabiad', 'None', 'English', 'liamcabiad@gmail.com', 'Singing', '638343', 'Catholic', 'Nueva Ecija', 'Jaen', 'Navao', 'Niyugan', 'Male', 'Married', '2001-06-10'),
(21, 'yyyyyyyy', 'yyyyyyyyyy', 'yyyyy', 'yyyyyyyyy', 'English', 'angelikasoledad22@gmail.com', 'Singing', '8888888', 'Catholic', 'Nueva Ecija', 'Jaen', 'Navao', 'San Josef (Nabao), Jaen, Nueva Ecija', 'yyyyyyyy', 'Single', '1111-11-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `educational_background`
--
ALTER TABLE `educational_background`
  ADD PRIMARY KEY (`education_id`),
  ADD KEY `personal_id` (`personal_id`);

--
-- Indexes for table `employment_history`
--
ALTER TABLE `employment_history`
  ADD PRIMARY KEY (`employment_id`),
  ADD KEY `personal_id` (`personal_id`);

--
-- Indexes for table `id`
--
ALTER TABLE `id`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `educational_background`
--
ALTER TABLE `educational_background`
  MODIFY `education_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `employment_history`
--
ALTER TABLE `employment_history`
  MODIFY `employment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `id`
--
ALTER TABLE `id`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `educational_background`
--
ALTER TABLE `educational_background`
  ADD CONSTRAINT `educational_background_ibfk_1` FOREIGN KEY (`personal_id`) REFERENCES `id` (`id`);

--
-- Constraints for table `employment_history`
--
ALTER TABLE `employment_history`
  ADD CONSTRAINT `employment_history_ibfk_1` FOREIGN KEY (`personal_id`) REFERENCES `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
