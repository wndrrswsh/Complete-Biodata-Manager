<?php
require 'Record.php';
require_once '../connections/db_connect5.php';

$Record = new Classes\Record($db);
$data = $Record->getAll();

include 'components/db_content_employment.php';
include '../libraries.php';
?>