<!DOCTYPE html>
<html lang="en">

<?php 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $Record->delete(intval($_POST['delete']));
    header('Location: index.php');
    exit;
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Information Records</title>
    <!-- <link rel="stylesheet" href="./style/bootstrap-5.3.8-dist/css/bootstrap.min.css"> -->
</head>

<body class="bg-light" style="font-family: 'Roboto', sans-serif;">

    <div class="container-fluid py-5 p-5">

        <div class="text-left mb-4">
            <h1 class="fw-bold mb-2 text-warning">Personal Profile</h1>
            <p class="text-muted">Individual Information Sheet Records</p>
        </div>

        <div class="d-flex justify-content-start mb-4">
            <a href="add.php" class="btn btn-warning px-4 py-2 rounded-pill shadow-sm text-white">
                + Add New Record
            </a>
        </div>

        <div class="card border-0 shadow-lg rounded-4 mb-5">
            <div class="card-body p-4">

                <div class="table-responsive text-nowrap">
                    <table class="table table-hover align-middle text-center">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Last Name</th>
                                <th>First Name</th>
                                <th>Middle Name</th>
                                <th>Suffix</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>Email Address</th>
                                <th>Province</th>
                                <th>City/Municipal</th>
                                <th>Brgy</th>
                                <th>Street</th>
                                <th>Mobile No</th>
                                <th>Language</th>
                                <th>Marital Status</th>
                                <th>Religion</th>
                                <th>Hobbies</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($data as $row) { ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= ucfirst($row['Last_name']) ?></td>
                                <td><?= ucfirst($row['First_name']) ?></td>
                                <td><?= ucfirst($row['Middle_name']) ?></td>
                                <td><?= ucfirst($row['Suffix']) ?></td>
                                <td><?= $row['DOB'] ?></td>
                                <td><?= ucfirst($row['Gender']) ?></td>
                                <td><?= ucfirst($row['Email_address']) ?></td>
                                <td><?= ucfirst($row['Province']) ?></td>
                                <td><?= ucfirst($row['City']) ?></td>
                                <td><?= ucfirst($row['Barangay']) ?></td>
                                <td><?= ucfirst($row['Street']) ?></td>
                                <td><?= ucfirst($row['Mobile_number']) ?></td>
                                <td><?= ucfirst($row['Languages']) ?></td>
                                <td><?= ucfirst($row['Marital_status']) ?></td>
                                <td><?= ucfirst($row['Religion']) ?></td>
                                <td><?= ucfirst($row['Hobbies']) ?></td>

                                <td>
                                    <div class="d-flex justify-content-center gap-1">
                                        <a href="view.php?id=<?= $row['id'] ?>"
                                            class="btn btn-outline-success btn-sm rounded-pill px-3">View</a>

                                        <a href="edit.php?id=<?= $row['id'] ?>"
                                            class="btn btn-outline-primary btn-sm rounded-pill px-3">Edit</a>

                                        <form method="POST" style="display:inline;">
                                            <button type="submit" name="delete" value="<?= $row['id'] ?>"
                                                class="btn btn-outline-danger btn-sm rounded-pill px-3">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>

    </div>

</body>

</html>