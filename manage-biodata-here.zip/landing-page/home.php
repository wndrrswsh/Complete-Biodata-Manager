<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>System</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp"
      rel="stylesheet"
    />
  </head>

  <body class="p-5">
    <!----------- HEADER ----------->
    <div class="row">
      <div class="col-sm-12 text-warning"><h5>BIODATA RECORDS</h5></div>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-6">
        <p class="fs-2">
          Organize and manage biodata <br />
          records efficiently.
        </p>
      </div>
      <div class="col-sm-12 col-md-6">
        <p class="des">
          Easily store, update, and access complete biodata information in one
          secure system. Designed to keep personal, educational, and employment
          records organized for faster retrieval and better record management.
        </p>
      </div>
    </div>
    <!----------- ROW 4 COLUMN ----------->
    <div class="row pt-5">
      <!----------- PERSONAL COLUMN ----------->
      <div class="col-md-4">
        <div class="card p-2 border-warning h-100">
          <div class="card-body">
            <a href="../personal_info/index.php" class="text-decoration-none text-dark">
              <span class="material-symbols-outlined fs-1 text-warning">
                contacts_product
              </span>
              <h4>Personal Information</h4>
              <p>
                Store essential personal details such as name, birthdate, address,
                contact information, and other basic identity records.
              </p>
            </a>
          </div>
        </div>
      </div>
      <!----------- EDUCATION COLUMN ----------->
      <div class="col-md-4">
        <div class="card p-2 border-warning h-100">
          <div class="card-body">
            <a href="../educational/index.php" class="text-decoration-none text-dark">
              <span class="material-symbols-outlined fs-1 text-warning">
                auto_stories
              </span>
              <h4>Education Information</h4>
              <p>
                Keep track of educational background including schools attended,
                degrees earned, and academic history.
              </p>
            </a>
          </div>
        </div>
      </div>
      <!-----------EMPLOYMENT COLUMN ----------->
      <div class="col-md-4">
        <div class="card p-2 border-warning h-100">
          <div class="card-body">
            <a href="../employment/index.php" class="text-decoration-none text-dark">
              <span class="material-symbols-outlined fs-1 text-warning"> badge </span>
              <h4>Employment Information</h4>
              <p>
                Manage work history, job positions, company details, and employment
                records in an organized database.
              </p>
            </a>
          </div>
        </div>
      </div>
    <!----------- VIEW RECORDS ----------->
    <div class="row pt-4">
      <div class="col-sm-12">
        <a href="../view_records/index.php" class="view-btn"
          >View All Records<span class="material-symbols-outlined">
            arrow_forward
          </span></a
        >
      </div>
    </div>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>

<!-- notes
rouded-1 [border radius]
text-muted
text-nowrap [class yan par di mag wrap ung text]
d-none d-md-block [hidden on sm]
d-md-none [Hidden on md and up] -->
