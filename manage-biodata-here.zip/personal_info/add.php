<?php
require_once "../connections/db_connect5.php";
require_once "Record.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Record</title>
    <link rel="stylesheet" href="../style/bootstrap-5.3.8-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style/style-custom/style.css">
</head>

<body class="bg-light" style="font-family: 'Roboto', sans-serif;">

    <div class="container py-5">
        <div class="card border-0 shadow-lg rounded-4 mx-auto" style="max-width: 1100px;">
            <div class="card-body p-4 p-md-5">

                <div class="text-left text-warning mb-4">
                    <h2 class="fw-bold">Individual Information Sheet</h2>
                    <p class="text-muted mb-0">Please fill out all required fields</p>
                </div>

                <form method="POST" action="add.php">

                    <div class="mb-5">
                        <h5 class="fw-bold border-bottom pb-2 mb-4 text-warning">Personal Details</h5>
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Last Name *</label>
                                <input type="text" class="form-control rounded-3" name="Last_name"
                                     required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">First Name *</label>
                                <input type="text" class="form-control rounded-3" name="First_name"
                                   required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Middle Name *</label>
                                <input type="text" class="form-control rounded-3" name="Middle_name"
                                   required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Suffix</label>
                                <input type="text" class="form-control rounded-3" name="Suffix"
                                    >
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Date of Birth *</label>
                                <input type="date" class="form-control rounded-3" name="DOB" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Gender *</label>
                                <input type="text" class="form-control rounded-3" name="Gender" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-5">
                        <h5 class="fw-bold border-bottom pb-2 mb-4 text-warning">Contact Information</h5>
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Mobile Number *</label>
                                <input type="text" class="form-control rounded-3" name="Mobile_number"
                                   required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Email Address *</label>
                                <input type="text" class="form-control rounded-3" name="Email_address"
                                    required>
                            </div>

                        </div>
                    </div>

                    <div class="mb-5">
                        <h5 class="fw-bold border-bottom pb-2 mb-4 text-warning">Address</h5>
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Street *</label>
                                <input class="form-control rounded-3" name="Street" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Barangay *</label>
                                <input class="form-control rounded-3" name="Barangay" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">City/Municipality *</label>
                                <input class="form-control rounded-3" name="City" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Province *</label>
                                <input class="form-control rounded-3" name="Province" required>
                            </div>

                        </div>
                    </div>

                    <div class="mb-5">
                        <h5 class="fw-bold border-bottom pb-2 mb-4 text-warning">Other Details</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Languages Known *</label>
                                <input type="text" class="form-control rounded-3" name="Languages" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Marital Status *</label>
                                <input type="text" class="form-control rounded-3" name="Marital_status" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Religion *</label>
                                <input type="text" class="form-control rounded-3" name="Religion" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Hobbies *</label>
                                <input type="text" class="form-control rounded-3" name="Hobbies" required>
                            </div>
                        </div>
                    </div>

                    <div class="text-left mt-4">
                        <button type="submit" name="add" class="btn btn-warning px-5 py-2 rounded-pill me-2">
                            Submit
                        </button>
                        <button type="reset" class="btn btn-outline-secondary px-5 py-2 rounded-pill">
                            Reset
                        </button>
                    </div>

                </form>

                <div class="text-left mt-4">
                    <a href="index.php" class="fw-semibold text-decoration-none text-warning">
                        View Records
                    </a>
                </div>

            </div>
        </div>
    </div>

</body>

</html>